"""
SQL Execution

High-level functions for executing SQL queries on Databricks.
"""

import logging
import re
from typing import Any, Dict, List, Optional

from databricks.sdk import WorkspaceClient

from .sql_utils import SQLExecutor, SQLExecutionError, SQLParallelExecutor
from .warehouse import get_best_warehouse

logger = logging.getLogger(__name__)

# A single unquoted SQL identifier: leading letter/underscore, then
# letters/digits/underscores. Deliberately stricter than a backtick-quoted
# identifier — these values are interpolated *unquoted* into SQL, so no spaces,
# dots, quotes, or backticks are allowed inside a single part.
_IDENT_PART = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def sql_identifier(name: str) -> str:
    """Validate a SQL identifier for safe *unquoted* interpolation into SQL.

    Unlike a string value, an identifier (table/column name) cannot be bound as
    a parameter and ``sql_literal()`` does not apply — it escapes literals, not
    identifiers. This is the companion guard for the identifier case: it rejects
    anything that isn't a plain dotted identifier before it reaches the query.

    Accepts a bare name (``col``) or a dotted name (``catalog.schema.table``);
    every dot-separated part must match ``[A-Za-z_][A-Za-z0-9_]*``. Returns the
    name unchanged so callers can inline it:

        >>> f"SELECT {sql_identifier(col)} FROM {sql_identifier(table)}"

    Args:
        name: The raw identifier (bare or dotted) to validate.

    Returns:
        The identifier unchanged, once validated.

    Raises:
        ValueError: If ``name`` is empty or any part is not a plain identifier.
    """
    if not name or not all(_IDENT_PART.match(part) for part in name.split(".")):
        raise ValueError(f"Invalid SQL identifier: {name!r}")
    return name


def sql_literal(value: str) -> str:
    """Escape a string for safe interpolation into a SQL single-quoted literal.

    Uses the ANSI doubled-quote convention (``'`` -> ``''``), which is the
    correct escaping for Databricks SQL string literals. Returns only the
    escaped inner text (no surrounding quotes), so callers wrap it themselves:

        >>> f"WHERE name = '{sql_literal(name)}'"

    Args:
        value: The raw string to escape.

    Returns:
        The value with every single quote doubled.
    """
    return value.replace("'", "''")


def execute_sql(
    sql_query: str,
    warehouse_id: Optional[str] = None,
    catalog: Optional[str] = None,
    schema: Optional[str] = None,
    timeout: int = 180,
    query_tags: Optional[str] = None,
    client: Optional[WorkspaceClient] = None,
) -> List[Dict[str, Any]]:
    """
    Execute a SQL query on a Databricks SQL Warehouse.

    If no warehouse_id is provided, automatically selects the best available
    warehouse using get_best_warehouse().

    Args:
        sql_query: SQL query to execute
        warehouse_id: Optional warehouse ID. If not provided, auto-selects one.
        catalog: Optional catalog context. If not provided, use fully qualified names.
        schema: Optional schema context. If not provided, use fully qualified names.
        timeout: Timeout in seconds (default: 180)
        query_tags: Optional query tags for cost attribution and filtering.
            Format: "key:value,key2:value2" (e.g., "team:eng,cost_center:701").
            Appears in system.query.history and Query History UI.
        client: Optional WorkspaceClient. When provided, both warehouse
            auto-selection and query execution run as that client's identity
            (e.g. a per-user OBO client); when omitted, falls back to the
            ambient client from get_workspace_client().

    Returns:
        List of dictionaries, each representing a row with column names as keys.
        Example: [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]

    Raises:
        SQLExecutionError: If query execution fails, with detailed error message:
            - No warehouse available
            - Warehouse not accessible
            - Query syntax error
            - Query timeout
            - Permission denied
    """
    # Auto-select warehouse if not provided
    if not warehouse_id:
        logger.debug("No warehouse_id provided, selecting best available warehouse")
        warehouse_id = get_best_warehouse(client=client)
        if not warehouse_id:
            raise SQLExecutionError(
                "No SQL warehouse available in the workspace. "
                "Please create a SQL warehouse or start an existing one, "
                "or provide a specific warehouse_id."
            )
        logger.debug(f"Auto-selected warehouse: {warehouse_id}")

    # Execute the query
    executor = SQLExecutor(warehouse_id=warehouse_id, client=client)
    return executor.execute(
        sql_query=sql_query,
        catalog=catalog,
        schema=schema,
        timeout=timeout,
        query_tags=query_tags,
    )


def execute_sql_multi(
    sql_content: str,
    warehouse_id: Optional[str] = None,
    catalog: Optional[str] = None,
    schema: Optional[str] = None,
    timeout: int = 180,
    max_workers: int = 4,
    query_tags: Optional[str] = None,
    client: Optional[WorkspaceClient] = None,
) -> Dict[str, Any]:
    """
    Execute multiple SQL statements with dependency-aware parallelism.

    Parses the SQL content into individual statements, analyzes dependencies
    between them (based on table creation and references), and executes them
    in optimal order. Queries that don't depend on each other run in parallel.

    If no warehouse_id is provided, automatically selects the best available
    warehouse using get_best_warehouse().

    Args:
        sql_content: SQL content with multiple statements separated by ;
        warehouse_id: Optional warehouse ID. If not provided, auto-selects one.
        catalog: Optional catalog context. If not provided, use fully qualified names.
        schema: Optional schema context. If not provided, use fully qualified names.
        timeout: Timeout per query in seconds (default: 180)
        max_workers: Maximum parallel queries per group (default: 4)
        query_tags: Optional query tags for cost attribution (e.g., "team:eng,cost_center:701").
        client: Optional WorkspaceClient. When provided, both warehouse
            auto-selection and query execution run as that client's identity
            (e.g. a per-user OBO client); when omitted, falls back to the
            ambient client from get_workspace_client().

    Returns:
        Dictionary with:
        - results: Dict mapping query index to result dict, each containing:
            - query_index: 0-based index of the query
            - status: "success" or "error"
            - execution_time: Time taken in seconds
            - query_preview: First 100 chars of the query
            - result_rows: Number of rows returned (for success)
            - sample_results: First 5 rows (for success)
            - error: Error message (for error)
            - error_category: Error type like SYNTAX_ERROR, MISSING_TABLE (for error)
            - suggestion: Hint on how to fix (for error)
            - group_number: Which execution group this query was in
            - is_parallel: Whether it ran in parallel with other queries
        - execution_summary: Overall statistics including:
            - total_queries: Number of queries parsed
            - total_groups: Number of execution groups
            - total_time: Total execution time
            - stopped_after_group: Group number where execution stopped (if error)
            - groups: List of group details

    Raises:
        SQLExecutionError: If parsing fails or no warehouse available

    Example:
        >>> result = execute_sql_multi('''
        ...     CREATE TABLE t1 AS SELECT 1 as id;
        ...     CREATE TABLE t2 AS SELECT 2 as id;
        ...     CREATE TABLE t3 AS SELECT * FROM t1 JOIN t2;
        ... ''')
        >>> # t1 and t2 run in parallel (no dependencies)
        >>> # t3 runs after both complete (depends on t1 and t2)
    """
    # Auto-select warehouse if not provided
    if not warehouse_id:
        logger.debug("No warehouse_id provided, selecting best available warehouse")
        warehouse_id = get_best_warehouse(client=client)
        if not warehouse_id:
            raise SQLExecutionError(
                "No SQL warehouse available in the workspace. "
                "Please create a SQL warehouse or start an existing one, "
                "or provide a specific warehouse_id."
            )
        logger.debug(f"Auto-selected warehouse: {warehouse_id}")

    # Execute with parallel executor
    executor = SQLParallelExecutor(
        warehouse_id=warehouse_id,
        max_workers=max_workers,
        client=client,
    )
    return executor.execute(
        sql_content=sql_content,
        catalog=catalog,
        schema=schema,
        timeout=timeout,
        query_tags=query_tags,
    )
