"""apx-agent — standalone agent runtime for Databricks Apps."""

# Agent types
from ._agents import (
    Agent,
    BaseAgent,
    HandoffAgent,
    LlmAgent,
    LoopAgent,
    ParallelAgent,
    RouterAgent,
    SequentialAgent,
)
from ._remote import RemoteDatabricksAgent

# Models
from ._models import (
    AgentCard,
    AgentConfig,
    AgentContext,
    AgentTool,
    AfterToolHook,
    BeforeToolHook,
    InputGuardrailFn,
    InvocationRequest,
    InvocationResponse,
    Message,
    OutputGuardrailFn,
    set_custom_output,
)

# FastAPI dependency injection
from ._defaults import Dependencies

# SQL utilities
from ._sql import get_warehouse_id, run_sql

# App factory and setup
from ._wiring import create_app, setup_agent

# Runner (OpenAI Agents SDK)
from ._runner import run_via_sdk, stream_via_sdk

# Eval bridge
from ._eval import app_predict_fn

# Genie tool factory
from .genie import genie_tool

# Unity Catalog tool factories
from .catalog import catalog_tool, lineage_tool, schema_tool, uc_function_tool

__all__ = [
    # Agent types
    "Agent",
    "BaseAgent",
    "HandoffAgent",
    "LlmAgent",
    "LoopAgent",
    "ParallelAgent",
    "RouterAgent",
    "SequentialAgent",
    "RemoteDatabricksAgent",
    # Models
    "AgentCard",
    "AgentConfig",
    "AgentContext",
    "AgentTool",
    "AfterToolHook",
    "BeforeToolHook",
    "InputGuardrailFn",
    "InvocationRequest",
    "InvocationResponse",
    "Message",
    "OutputGuardrailFn",
    "set_custom_output",
    # Dependencies
    "Dependencies",
    # SQL utilities
    "get_warehouse_id",
    "run_sql",
    # App factory
    "create_app",
    "setup_agent",
    # Runner
    "run_via_sdk",
    "stream_via_sdk",
    # Eval
    "app_predict_fn",
    # Genie
    "genie_tool",
    # Unity Catalog
    "catalog_tool",
    "lineage_tool",
    "schema_tool",
    "uc_function_tool",
]
